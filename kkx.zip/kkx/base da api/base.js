case '':
					data = fs.readFileSync('./nomedapasta/nomedaapi.js');
                 jsonData = JSON.parse(data);
                 randIndex = Math.floor(Math.random() * jsonData.length);
                 randKey = jsonData[randIndex];
                 buffer = await getBuffer(randKey.result)
				client.sendMessage(from, buffer, image, {caption: 'aqui está:)', quoted: mek})
                 break