[
{"result": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJtqk_wKfcyv2WCKyl93E5uBmA-KsnfYy4PQ&usqp=CAU"},
{"result": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT-2bNT_-nmeTrXZ63RFsRZfLd1V5fMk3c1Eg&usqp=CAU"}
]
