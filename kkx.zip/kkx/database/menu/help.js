const help = (pushname, prefix, botName, ownerName, reqXp, uangku) => { 
return ` 
⧚⧚⧚⧚⧚⧚⧚⧚〘 Informações 〙⧚⧚⧚⧚⧚⧚⧚
║ 
║ *𒋨 Criador :*
║ *𒆖 wa.me/554497763474*
║ *𒆖 .owner*
║ *𒋨 Prefix : 「 ${prefix} 」*
║ *𒋨 Nome do Bot : 「${botName}」*
║ *𒋨 Usuario : 「${pushname}️」*
║ *𒋨 XP: 「${reqXp}」*
║ *𒋨 Coins: 「${uangku}」*
║ 
 ⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚
║
║𒋨 🜊 *Entretenimento* 🜊
║
║𒆖 *${prefix}s*
║𒆖 *${prefix}sticker*
║𒆖 *${prefix}toimg*
║𒆖 *${prefix}tts*
║𒆖 *${prefix}musica*
║𒆖 *${prefix}tomp3*
║𒆖 *${prefix}leens*
║𒆖 *${prefix}avalie*
║𒆖 *${prefix}lgbt*
║𒆖 *${prefix}gado*
║𒆖 *${prefix}send*
║𒆖 *${prefix}wame*
║𒆖 *${prefix}qrcode*
║𒆖 *${prefix}timer*
║𒆖 *${prefix}iplog*
║𒆖 *${prefix}listadmins*
║𒆖 *${prefix}clone*
║
 ⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚
║
║𒋨 🜊 *Group Admins* 🜊
║
║𒆖 *${prefix}remover*
║𒆖 *${prefix}add*
║𒆖 *${prefix}gnome*
║𒆖 *${prefix}gdesc*
║𒆖 *${prefix}glink*
║𒆖 *${prefix}gfechar*
║𒆖 *${prefix}gabrir*
║𒆖 *${prefix}setppbot*
║𒆖 *${prefix}glink*
║𒆖 *${prefix}here*
║
 ⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚
║
║𒋨 🜊 *Bot Admins* 🜊
║
║𒆖 *${prefix}setprefix*
║𒆖 *${prefix}block*
║𒆖 *${prefix}tm*
║𒆖 *${prefix}tmctt*
║𒆖 *${prefix}clearall*
║𒆖 *${prefix}antilink*
║
 ⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚
║
║𒋨 🜊 *Temporariamente Off* 🜊
║
║𒆖 *${prefix}ytmp3*
║𒆖 *${prefix}ytmp4*
║𒆖 *${prefix}img*
║
 ⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚⧚
 ` 
} 
exports.help = help